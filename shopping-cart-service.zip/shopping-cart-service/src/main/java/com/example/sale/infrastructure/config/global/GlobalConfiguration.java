package com.example.sale.infrastructure.config.global;

import org.springframework.context.annotation.Configuration;

@Configuration
public class GlobalConfiguration {

}
