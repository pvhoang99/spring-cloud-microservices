package com.example.sale.domain.cart;

public enum Status {

    PENDING, APPROVED, DENIED

}
